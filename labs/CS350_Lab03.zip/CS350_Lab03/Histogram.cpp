#include <iostream>
#include "Histogram.h"

Histogram::Histogram(int numBuckets)
{
    // TODO: create an array of int elements,
    // assign a pointer to it to the int* field (i.e. m_counts)

    // TODO: store numBuckets in the int field (i.e., m_numBuckets)
}

Histogram::Histogram(const Histogram &other)
{
    // TODO: allocate new int array, copy contents from other's int array

    // TODO: copy other's bucket count
}

Histogram::~Histogram()
{
    // TODO: use the delete[] operator to de-allocate
    // the array of ints
}

Histogram& Histogram::operator=(const Histogram &rhs)
{
    // TODO: delete old array

    // TODO: create new array, copy contents from rhs

    return *this;
}

// TODO: define the other methods
void Histogram::increaseCount(int bucket)
{
    // TODO: increase the count in the specified bucket
}

int Histogram::getCount(int bucket) const
{
    // TODO: return the count in the specified bucket
}
