#include <vector>
#include <list>
#include <iostream>
#include <cstdint>

const int CHUNK = 10000;

uint64_t utime();

int main(void)
{
    std::cout << "n,vector_time,list_time" << std::endl;

    for (int n = CHUNK; n <= 10*CHUNK; n += CHUNK) {
        std::cout << n << "," << std::flush;

        {
            uint64_t elapsed = 0;

            // TODO: benchmark time to add n elements to front of a std::vector

            std::cout << elapsed << "," << std::flush;
        }

        {
            uint64_t elapsed = 0;

            // TODO: benchmark time to add n elements to front of a std::list

            std::cout << elapsed << std::flush;
        }

        std::cout << std::endl;
    }

    return 0;
}
