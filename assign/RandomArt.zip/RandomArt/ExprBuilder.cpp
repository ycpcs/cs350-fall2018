//
//  ExprBuilder.cpp
//

#include <cstdlib>
#include <cassert>
#include "ExprBuilder.h"
#include "ExprNode.h"

// Each random expression tree has a maximum depth
const int MAX_DEPTH = 12;

ExprBuilder::ExprBuilder()
{
}

ExprBuilder::~ExprBuilder()
{
}

ExprNode *ExprBuilder::build() const
{
    // TODO: return a random expression tree instead of this XNode
    // Suggestion: call a recursive helper method that takes the
    // current depth as a parameter.
    return new XNode();
}
